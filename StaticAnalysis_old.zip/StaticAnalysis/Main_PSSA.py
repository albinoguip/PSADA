import time
import sys
import os

from Analyze_Save_Info import *



def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    print(base_path, relative_path)

    return os.path.join(base_path, relative_path)





if __name__ == '__main__':

    start_time = time.time()

    # ************************************************************************************************
    #                                       OPÇÕES DE EJECUÇÃO                                       *
    # ************************************************************************************************

    Options_ReadProcess= {
                            'Norm': 2,          # Write None for using infinite norm in voltage analysis
                            'OneCase': 1,       # (1) for All cases or (2) for Just One Case analysis
                            'SavePath': "C:/Users/Gabriel/Desktop/PSADA/V2A2F2_REV2_2026/",
        # ---------------------------------------------------
                            'generatescript' : False,  # Put TRUE just for generate the script for simulation and saving the flows in Organon
                            'OnlyPWF_datagen': False,   # Put TRUE just for generate the data for Interconnection and Line Flow Analysis
                            'extract_fromcsv' :False,   # Put TRUE just in the first simulation, once the ProcessedDataBase.csv is generated it is not necessary
                            'savedata':False,            # To save the data of the electric variables in the folders
                            'busdata' : True,           # Let like TRUE
        # ---------------------------------------------------
                            'ConvergenceData' : False,   # To analyze just the converged cases   
                            'LinhasData': False,
                            'HVDCData':False,
                            'ReservaData':False,
                            'IntercambiosData':False,
                            'ComputeDPI': False,
                            'resumoIndice': False,
        # ---------------------------------------------------
                            'linhascsv':False,          # Put TRUE once is generated the LinhasInfo file
                            'reservacsv':False,         # Put TRUE once is generated the ReserveInfo file
                            'HVDCcsv': False,            # Put TRUE once is generated the HVDCinfo file
        # ---------------------------------------------------
                            'PlotGeralPotencia': False,
                            'MapasPlots': False,
                            'Plot_Tensao_Geral': False,
                            'plotDPI': False,
                            'Plot_Boxplot_DPI': False,
                            'PlotIntercambios': False
                        }
    # print("Deu certo", Options_ReadProcess['generatescript'])

    # ************************************************************************************************
    #                                              PATHS
    # ************************************************************************************************

    # =============================             CASOS 2022          ===========================================
    # path_folder = 'D:/MPV_(FNS Lim)_RC/'
    # path_folder_1 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2022/Novos com FNS Lim/V1A1F2 FNS Lim 2022/'
    # path_folder_2 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2022/Novos com FNS Lim/V1A1F2 FNS Lim 2022_OPF/'
    # path_folder ='D:/0 FERV/0 Dados PYTHON/CASOS 2022/Antigos/MPV_(FNS Lim)_RC/'
    # path_folder = 'D:/0 FERV/0 Dados PYTHON/CASOS 2022/Novos com FNS Lim/V2A2F2 FNS Lim 2022/'

    # =============================         CASOS 2026 V1A1         ===========================================
    # path_folder_1 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V1A1F_/REV_1_02/V1A1F2_RESP_FNS_lim_rev1_2026/'
    # path_folder_2 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V1A1F_/REV_1_02/V1A1F3_RESP_FNS_lim_rev1_2026/'
    # path_folder_3 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V1A1F_/REV_1_02/V1A1F4_RESP_FNS_lim_rev1_2026/'
    # path_folder_4 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V1A1F_/REV_1_02/V1A1F5_RESP_FNS_lim_rev1_2026/'
    # path_folder = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V1A1F_/REV_2/V1A1F2_RESP_FNS_lim_rev2_2026/'

    # =============================         CASOS 2026 V2A2F       =========================================== 
    # path_folder_5 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V2A2F_/REV_2/V2A2F2_REV02_2026/'
    path_folder = 'C:/Users/Gabriel/Desktop/PSADA/V2A2F2_REV2_2026/'
    # path_folder_6 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V2A2F_/REV_2/V2A2F3_REV02_2026/'
    # path_folder_7 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V2A2F_/REV_2/V2A2F4_REV02_2026/'
    # path_folder_8 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V2A2F_/REV_2/V2A2F5_REV02_2026/'

    # =============================         CASOS 2026 V3A3F       ===========================================
    # path_folder_1 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_0/V3A3F2_REV0_2026/'
    # path_folder_2 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_0/V3A3F3_REV0_2026/'
    # path_folder_3 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_0/V3A3F4_REV0_2026/'
    # path_folder_4 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_0/V3A3F5_REV0_2026/'

    # path_folder_1 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_1/V3A3F2_REV1_2026/'
    # path_folder_2 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_1/V3A3F3_REV1_2026/'
    # path_folder_3 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_1/V3A3F4_REV1_2026/'
    # path_folder_9 = 'D:/0 FERV/0 Dados PYTHON/CASOS 2026/V3A3F_/REV_1/V3A3F5_REV1_2026/'

    # ============================= List of PATHS ===========================================
    # path_folders = [path_folder_1, path_folder_2, path_folder_3, path_folder_4,path_folder_5,path_folder_6,path_folder_7,path_folder_8,path_folder_9]
    path_folders = [path_folder]

    for path_folder in path_folders:

        cenarios = AnalyzeStaticCases(path=path_folder, Options = Options_ReadProcess)
        cenarios.extraction_process()
        cenarios.LinhaAnalise()
        cenarios.ReservaAnalise()
        cenarios.ActiveReactivePower()
        cenarios.Plot_Tensao_Geral()
        cenarios.MapasPlots()
        cenarios.ComputeDPI()
        cenarios.save_csv()

    end_time = time.time()
    execution_time = end_time - start_time
    print("Tiempo de ejecución:", execution_time, "segundos")